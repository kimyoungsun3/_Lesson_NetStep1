﻿using SocketGlobal;
using SocketGlobal.SendData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SocketAsync_Client
{
	#region 외부에 연결할 델리게이트
	public delegate void dgSocketClient_ConnectComplete();
	/// <summary>
	/// 접속끊김을 알림
	/// </summary>
	public delegate void dgSocketClient_Disconnect();
	/// <summary>
	/// 전송된 메시지가 완성 되었다.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	public delegate void dgSocketClient_MessageComplete(CSendData sdMessage);
	/// <summary>
	/// 메시지 보내기 완료
	/// </summary>
	public delegate void dgSocketClient_SendComplete();
	#endregion

	public class CSocketClient
	{
		#region 연결할 이벤트 ♥♥♥♥♥♥♥♥♥♥♥♥
		/// <summary>
		/// 서버에 접속이 완료됨
		/// </summary>
		public event dgSocketClient_ConnectComplete OnConnectComplete;
		/// <summary>
		/// 접속이 끊어짐
		/// </summary>
		public event dgSocketClient_Disconnect OnDisconnect;
		/// <summary>
		/// 메시지 리시브 완료
		/// </summary>
		public event dgSocketClient_MessageComplete OnMessageComplete;
		/// <summary>
		/// 메시지 보내기가 완료 되었다.
		/// </summary>
		public event dgSocketClient_SendComplete OnSendComplete;
		#endregion

		/// <summary>
		/// 이 유저의 소켓정보
		/// </summary>
		private Socket m_socketMe { get; set; }


		/// <summary>
		/// 큰데이터 받기용
		/// </summary>
		private CLargeData_Manager_SAEA m_LD_GM
			= new CLargeData_Manager_SAEA(100);

		public CSocketClient(Socket socketUser)
		{
			this.m_socketMe = socketUser;
			//this.BeginReceive();
		}


		public void BeginReceive()
		{
			if (true == this.m_socketMe.Connected)
			{
				CSendData_Original dsReceiveMsg = new CSendData_Original();
				//연결완료용 데이터는 
				dsReceiveMsg.Data = CGlobal.g_SocketUtile.Buffer_GetBasicButter;

				//서버에 보낼 객체를 만든다.
				SocketAsyncEventArgs saeaReceiveArgs = new SocketAsyncEventArgs();
				//보낼 데이터를 설정하고
				saeaReceiveArgs.UserToken = dsReceiveMsg.Data;
				//데이터 길이 세팅
				saeaReceiveArgs.SetBuffer(dsReceiveMsg.getBitConverter(), 0, dsReceiveMsg.ButterCount);
				//받음 완료 이벤트 연결
				saeaReceiveArgs.Completed += SaeaReceiveArgs_Completed;
				//받음 보냄
				m_socketMe.ReceiveAsync(saeaReceiveArgs);

				//서버에 접속 완료 이벤트
				this.OnConnectComplete();
			}
			else
			{
				Disconnect_Call();
			}
		}

		private void SaeaReceiveArgs_Completed(object sender, SocketAsyncEventArgs e)
		{
			Socket socketClient = (Socket)sender;
			CSendData_Original mdRecieveMsg = new CSendData_Original();

			int nAvailable = socketClient.Available;

			if (false == socketClient.Connected)
			{   //유저의 접속이 끊겼다.
				//접속 끊김을 알린다.
				this.Disconnect_Call();
				return;
			}

			if (0 >= nAvailable)
			{   //수신된 바이트가 없다.

				//지정된 시간만큼 기다린다.
				Thread.Sleep(50);

				//다시 수신된 바이트를 체크한다.
				nAvailable = socketClient.Available;


				if (0 >= nAvailable)
				{   //여전히 없다.
					//이렇게 되면 처리할 내용이 없다는 의미이므로 과정을 생략한다.
					this.m_LD_GM.SkipStep = true;
				}
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Wait))
			{   //데이터를 받는 중이다.

				//전체 버퍼의 크기를 읽어온다.
				mdRecieveMsg.Length = BitConverter.ToInt32(e.Buffer, 0);

				//버퍼에 저장하기를 시작한다.
				this.m_LD_GM.StartBuffer(mdRecieveMsg.Length);
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Receiving))
			{   //데이터를 받는 중이다.

				if (false == this.m_LD_GM.BufferCheck)
				{   //버퍼를 체크하지 않았다.
					//버퍼를 체크하지 않았다면 해더용 버퍼까지 데이터로 취급하여
					//데이터를 받아야 한다.
					this.m_LD_GM.SetBuffer_HeaderTemp(e.Buffer);
				}

				//임시버퍼의 크기를 설정하고
				this.m_LD_GM.SetBuffer_BadyTemp(nAvailable);
				//임시 버퍼에 데이터를 데이터를 넣는다.
				socketClient.Receive(this.m_LD_GM.Buffer_BadyTemp, nAvailable, SocketFlags.None);
				//임시 버퍼의 데이터를 전체 버퍼로 옮깁니다.
				this.m_LD_GM.WriteBufferTemp_All();
				/*
				Console.WriteLine("ReceiveBufferSize : {0}", e.Count);
				Console.WriteLine("        Available : {0}", nAvailable);

				Console.WriteLine(" BufferCompleat : TotalBufferSize {0} - WriteCount {1} - State {2}"
					, this.m_LD_GM.TotalBufferSize
					, this.m_LD_GM.WriteCount
					, this.m_LD_GM.State.ToString());*/
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Compleat))
			{   //데이터가 완성 되었다.

				//전체 버퍼의 크기를 지정하고.
				mdRecieveMsg.Length = this.m_LD_GM.TotalBufferSize;
				//완성 데이터에 버퍼를 옮기고
				mdRecieveMsg.Data = this.m_LD_GM.Buffer;

				//넘어온 메시지를 분석의뢰!
				this.OnMessageComplete(new CSendData(mdRecieveMsg));

				//메니저 초기화
				this.m_LD_GM.Reset();
			}

			if (true == this.m_LD_GM.SkipStep)
			{   //스킵하고 왔다면
				//스킵을 복구한다.
				this.m_LD_GM.SkipStep = false;
			}

			//다음 데이터를 기다린다.
			socketClient.ReceiveAsync(e);
		}

		/// <summary>
		/// 접속이 끊겼다.
		/// </summary>
		public void Disconnect_Call()
		{
			//접속 끊김
			m_socketMe = null;

			//유아이를 세팅하고
			this.OnDisconnect();

			//DisplayMsg("*** 서버 연결 끊김 ***");
		}

		public void SendMsg(CSendData dsSendMsg)
		{
			CSendData_Original doSendMsg = dsSendMsg.CreateDataOriginal();

			//서버에 보낼 객체를 만든다.
			SocketAsyncEventArgs saeaServer = new SocketAsyncEventArgs();
			//데이터 길이 세팅
			saeaServer.SetBuffer(doSendMsg.getBitConverter(), 0, doSendMsg.ButterCount);
			//보내기 완료 이벤트 연결
			saeaServer.Completed += new EventHandler<SocketAsyncEventArgs>(Send_Completed);
			//보낼 데이터 설정
			saeaServer.UserToken = doSendMsg.Data;

			bool completedAsync = false;

			try
			{
				//보내기
				completedAsync = m_socketMe.SendAsync(saeaServer);
			}
			catch
			{
			}

			if (!completedAsync)
			{
				// The call completed synchronously so invoke the callback ourselves
				Send_Completed(this, saeaServer);
			}
		}

		/// <summary>
		/// 메시지 보내기 완료
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Send_Completed(object sender, SocketAsyncEventArgs e)
		{
			Socket socketSend = (Socket)sender;
			CSendData_Original dsMsg = new CSendData_Original();
			dsMsg.Data = (byte[])e.UserToken;
			socketSend.Send(dsMsg.Data);

			//메시지 보내기가 완료 되었다.
			this.OnSendComplete();
		}

	}
}
