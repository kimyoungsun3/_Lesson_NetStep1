﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net;

namespace SocketAsync
{
	public class AsyncTask
	{
		public byte[] ReceiveBuffer { get; private set; }
		public int TotalBytesReceived { get; set; }
		public int BytesReceived { get; set; }
		public string DocSource { get; set; }
		public string Host { get; private set; }
		public int Port { get; private set; }
		public string Path { get; private set; }
		public IPAddress[] Addresses { get; private set; }
		public AsyncTask(string host, int port, string path)
		{
			ReceiveBuffer = new byte[256];
			TotalBytesReceived = 0;
			BytesReceived = -1; // can't be zero!
			Host = host;
			Port = port;
			Path = path;
			Addresses = Dns.GetHostEntry(Host).AddressList;
		}
	}
}
