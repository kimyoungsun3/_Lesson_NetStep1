﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.Net.Sockets;

using SocketGlobal;
using SocketGlobal.Utility;
using System.Threading;
using SocketGlobal.SendData;

namespace SocketAsync_Server
{
	/// <summary>
	/// 유저 클래스
	/// </summary>
	public class claUser
	{
		#region 연결할 이벤트 ♥♥♥♥♥♥♥♥♥♥♥♥
		/// <summary>
		/// 접속
		/// </summary>
		public event dgConnect OnConnected;
		/// <summary>
		/// 끊김
		/// </summary>
		public event dgDisconnect OnDisconnected;
		/// <summary>
		/// 메시지
		/// </summary>
		public event dgMessage OnMessaged;
		#endregion

		/// <summary>
		/// 명령어 클래스
		/// </summary>
		private CCommand m_insCommand = new CCommand();

		/// <summary>
		/// 이 유저의 소켓정보
		/// </summary>
		//public Socket m_socketMe;
		public CSocketUser Socket_User;

		/// <summary>
		/// 이 유저의 아이디
		/// </summary>
		public string UserID { get; set; }

		/// <summary>
		/// 큰데이터 받기용
		/// </summary>
		private CLargeData_Manager_SAEA m_LD_GM
			= new CLargeData_Manager_SAEA(100);

		/// <summary>
		/// 유저 객체를 생성합니다.
		/// </summary>
		/// <param name="socketClient">접속된 유저의 소켓</param>
		public claUser(Socket socketClient)
		{
			//소켓 저장
			this.Socket_User = new CSocketUser(socketClient);
			this.Socket_User.OnDisconnect += Disconnected;
			this.Socket_User.OnMessageComplete += Socket_User_OnMessageComplete;
			this.Socket_User.OnSendComplete += Socket_User_OnSendComplete;

		}

		private void Socket_User_OnMessageComplete(CSendData sdMessage)
		{
			Console.WriteLine(" command : {0}", sdMessage.Command.ToString());

			switch (sdMessage.Command)
			{
				case CCommand.Command.None: //없다
					break;
				case CCommand.Command.Msg:  //메시지인 경우
				case CCommand.Command.ID_Check: //아이디 체크
				case CCommand.Command.User_List_Get:    //유저리스트 갱신 요청
				case CCommand.Command.Image:    //이미지
					SendMeg_Main(sdMessage);
					break;

				case CCommand.Command.Login:    //로그인 완료
					OnConnected(this);
					break;
			}
		}

		private void Socket_User_OnSendComplete()
		{
			
		}


		/// <summary>
		/// 나 연결 됨.
		/// </summary>
		public void Connected()
		{
			OnConnected(this);
		}

		/// <summary>
		/// 나 끊김
		/// </summary>
		public void Disconnected()
		{
			OnDisconnected(this);
		}


		/// <summary>
		/// 서버로 메시지를 보냅니다.
		/// </summary>
		/// <param name="sMag"></param>
		private void SendMeg_Main(CSendData dsRecieveMsg)
		{
			OnMessaged(this, dsRecieveMsg);
		}
		

		public void SendMsg_User(CCommand.Command typeCommand, string sMsg)
		{
			CSendData dsMsg = new CSendData();
			dsMsg.Command = typeCommand;
			dsMsg.Data_String = sMsg;
			this.SendMsg_User(dsMsg);
        }

		public void SendMsg_User(CCommand.Command typeCommand, byte[] byteData)
		{
			CSendData sdSendMsg = new CSendData();

			//데이터를 넣고
			sdSendMsg.Command = typeCommand;
			sdSendMsg.Data_Byte = byteData;

			this.SendMsg_User(sdSendMsg);
		}

		/// <summary>
		/// 이 유저에게 메시지를 보낸다.
		/// </summary>
		/// <param name="sMsg"></param>
		public void SendMsg_User(CSendData sdMsg)
		{
			this.Socket_User.SendMessage(sdMsg);
		}

		/// <summary>
		/// 메시지 보내기 완료
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Send_Completed(object sender, SocketAsyncEventArgs e)
		{
			//유저 소켓
			Socket socketClient = (Socket)sender;
			CSendData_Original mdMsg = new CSendData_Original();
            mdMsg.Data = (byte[])e.UserToken;
			//데이터 보내기 마무리
			socketClient.Send(mdMsg.Data);
		}

	}
}
