﻿using System.Net.Sockets;

using SocketGlobal.SendData;
using System.Threading;
using System;

namespace SocketGlobal
{
	#region 외부에 연결할 델리게이트
	/// <summary>
	/// 접속끊김을 알림
	/// </summary>
	public delegate void dgUserSocket_Disconnect();
	/// <summary>
	/// 전송된 메시지가 완성 되었다.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	public delegate void dgUserSocket_MessageComplete(CSendData sdMessage);
	/// <summary>
	/// 메시지 보내기 완료
	/// </summary>
	public delegate void dgUserSocket_SendComplete();
	#endregion

	public class CSocketUser
	{

		#region 연결할 이벤트 ♥♥♥♥♥♥♥♥♥♥♥♥
		/// <summary>
		/// 유저 끊어짐
		/// </summary>
		public event dgUserSocket_Disconnect OnDisconnect;
		/// <summary>
		/// 메시지 리시브 완료
		/// </summary>
		public event dgUserSocket_MessageComplete OnMessageComplete;
		/// <summary>
		/// 메시지 보내기가 완료 되었다.
		/// </summary>
		public event dgUserSocket_SendComplete OnSendComplete;
		#endregion


		/// <summary>
		/// 이 유저의 소켓정보
		/// </summary>
		private Socket m_socketMe;


		/// <summary>
		/// 큰데이터 받기용
		/// </summary>
		private CLargeData_Manager_SAEA m_LD_GM
			= new CLargeData_Manager_SAEA(100);

		public CSocketUser(Socket socketUser)
		{
			this.m_socketMe = socketUser;
			this.BeginReceive();
		}

		private void BeginReceive()
		{
			//데이터 구조 생성
			CSendData_Original MsgData = new CSendData_Original();
			//리시브용 인스턴스 생성
			SocketAsyncEventArgs saeaReceiveArgs = new SocketAsyncEventArgs();
			//리시브용 데이터 구조 지정
			saeaReceiveArgs.UserToken = MsgData.Data;
			//리시브용 데이터버퍼 설정
			saeaReceiveArgs.SetBuffer(CGlobal.g_SocketUtile.Buffer_GetBasicButter
										, 0
										, CGlobal.g_SocketUtile.Buffer_GetBasicSize);
			//유저한테서 넘어온 데이터 받음 완료 이벤트 연결
			saeaReceiveArgs.Completed += new EventHandler<SocketAsyncEventArgs>(Recieve_Completed);
			//데이터 받기 시작
			bool bRC = m_socketMe.ReceiveAsync(saeaReceiveArgs);

			if (false == bRC)
			{
				Recieve_Completed(this, saeaReceiveArgs);
			}
		}


		/// <summary>
		/// 유저한테서 넘어온 데이터 받음 완료
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Recieve_Completed(object sender, SocketAsyncEventArgs e)
		{
			//서버에서 넘어온 정보
			Socket socketClient = (Socket)sender;
			//서버에서 넘어온 데이터
			CSendData_Original MsgData = new CSendData_Original();

			int nAvailable = socketClient.Available;

			if (false == socketClient.Connected)
			{   //유저의 접속이 끊겼다.
				//접속 끊김을 알린다.
				this.Disconnect_Call();
				return;
			}

			if (0 >= nAvailable)
			{   //수신된 바이트가 없다.

				//지정된 시간만큼 기다린다.
				Thread.Sleep(50);

				//다시 수신된 바이트를 체크한다.
				nAvailable = socketClient.Available;


				if (0 >= nAvailable)
				{   //여전히 없다.
					//이렇게 되면 처리할 내용이 없다는 의미이므로 과정을 생략한다.
					this.m_LD_GM.SkipStep = true;
				}
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Wait))
			{   //데이터를 받는 중이다.

				//전체 버퍼의 크기를 읽어온다.
				MsgData.Length = BitConverter.ToInt32(e.Buffer, 0);

				//버퍼에 저장하기를 시작한다.
				this.m_LD_GM.StartBuffer(MsgData.Length);
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Receiving))
			{   //데이터를 받는 중이다.

				if (false == this.m_LD_GM.BufferCheck)
				{   //버퍼를 체크하지 않았다.
					//버퍼를 체크하지 않았다면 해더용 버퍼까지 데이터로 취급하여
					//데이터를 받아야 한다.
					this.m_LD_GM.SetBuffer_HeaderTemp(e.Buffer);
				}

				//임시버퍼의 크기를 설정하고
				this.m_LD_GM.SetBuffer_BadyTemp(nAvailable);
				//임시 버퍼에 데이터를 데이터를 넣는다.
				socketClient.Receive(this.m_LD_GM.Buffer_BadyTemp, nAvailable, SocketFlags.None);
				//임시 버퍼의 데이터를 전체 버퍼로 옮깁니다.
				this.m_LD_GM.WriteBufferTemp_All();
				/*
				Console.WriteLine("ReceiveBufferSize : {0}", e.Count);
				Console.WriteLine("        Available : {0}", nAvailable);

				Console.WriteLine(" BufferCompleat : TotalBufferSize {0} - WriteCount {1} - State {2}"
					, this.m_LD_GM.TotalBufferSize
					, this.m_LD_GM.WriteCount
					, this.m_LD_GM.State.ToString());*/
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Compleat))
			{   //데이터가 완성 되었다.

				//전체 버퍼의 크기를 지정하고.
				MsgData.Length = this.m_LD_GM.TotalBufferSize;
				//완성 데이터에 버퍼를 옮기고
				MsgData.Data = this.m_LD_GM.Buffer;

				//넘어온 메시지를 분석의뢰!
				this.OnMessageComplete(new CSendData(MsgData));

				//메니저 초기화
				this.m_LD_GM.Reset();
			}

			if (true == this.m_LD_GM.SkipStep)
			{   //스킵하고 왔다면
				//스킵을 복구한다.
				this.m_LD_GM.SkipStep = false;
			}

			//다음 데이터를 기다린다.
			socketClient.ReceiveAsync(e);
		}

		/// <summary>
		/// 이 유저에게 메시지를 보낸다.
		/// </summary>
		/// <param name="sMsg"></param>
		public void SendMessage(CSendData dsMsg)
		{
			CSendData_Original mdMsg = dsMsg.CreateDataOriginal();

			//유저에게 보낼 객체를 만든다.
			SocketAsyncEventArgs saeaSendArgs = new SocketAsyncEventArgs();
			//데이터 길이 세팅
			saeaSendArgs.SetBuffer(mdMsg.getBitConverter(), 0, mdMsg.ButterCount);
			//보내기 완료 이벤트 연결
			saeaSendArgs.Completed += new EventHandler<SocketAsyncEventArgs>(Send_Completed);
			//보낼 데이터 설정
			saeaSendArgs.UserToken = mdMsg.Data;
			//보내기
			this.m_socketMe.SendAsync(saeaSendArgs);
		}

		/// <summary>
		/// 메시지 보내기 완료
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Send_Completed(object sender, SocketAsyncEventArgs e)
		{
			//유저 소켓
			Socket socketClient = (Socket)sender;
			CSendData_Original mdMsg = new CSendData_Original();
			mdMsg.Data = (byte[])e.UserToken;
			//데이터 보내기 마무리
			socketClient.Send(mdMsg.Data);

			//보내기가 완료되었다고 알린다.
			this.OnSendComplete();
		}

		public void Disconnect_Call()
		{
			//소켓을 닫고
			if (true == this.m_socketMe.Connected)
			{
				this.m_socketMe.Disconnect(false);
			}


			//끊김을 알린다.
			this.OnDisconnect();
		}

	}
}
