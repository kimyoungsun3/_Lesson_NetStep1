﻿using System;

using CustomClass;

namespace SocketGlobal
{
	public class CSocketUtil : CEncoding
	{
		#region 버퍼 관련
		/// <summary>
		/// 새로 만든 버퍼를 받는다.
		/// </summary>
		/// <returns></returns>
		public byte[] Buffer_GetButter
		{
			get
			{
				return new byte[CGlobal.g_FullBuffer];
			}
		}

		/// <summary>
		/// 버퍼의 최대 사이즈
		/// </summary>
		/// <returns></returns>
		public int Buffer_GetButterSize
		{
			get
			{
				return CGlobal.g_FullBuffer;
			}
		}

		/// <summary>
		/// 기본 버퍼
		/// </summary>
		public byte[] Buffer_GetBasicButter
		{
			get
			{
				return new byte[CGlobal.g_BasicBuffer];
			}
		}

		/// <summary>
		/// 버퍼의 기본 사이즈
		/// </summary>
		/// <returns></returns>
		public int Buffer_GetBasicSize
		{
			get
			{
				return CGlobal.g_BasicBuffer;
			}
		}
			#endregion

		/// <summary>
		/// 지정한 숫자를 'g_DataHeader1Size'의 크기에 맞게 헤더를 생성합니다.
		/// </summary>
		/// <param name="intData"></param>
		/// <returns></returns>
		public byte[] IntToByte(int intData)
		{
			return base.StringToByte(string.Format("{0:D10}", intData.GetHashCode()));
		}

		/// <summary>
		/// 지정한 바이트배열을 숫자로 바꿔준다.
		/// </summary>
		/// <param name="byteData"></param>
		/// <returns></returns>
		public int ByteToInt(byte[] byteData)
		{
			return CGlobal.g_Number.StringToInt(base.ByteToString(byteData));
		}

		
	}
}
