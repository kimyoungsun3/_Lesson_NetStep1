﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocketGlobal.SendData
{
	/// <summary>
	/// 메시지를 주고받기전에 바이트로 변환전 데이터를 가지고 있는 클래스.
	/// </summary>
	public class CSendData
	{
		/// <summary>
		/// 명령어
		/// </summary>
		public CCommand.Command Command { get; set; }

		/// <summary>
		/// 데이터(byte[]), 우선순위 1.
		/// </summary>
		public byte[] Data_Byte { get; set; }
		public string Data_Byte_ToString() { return CSocketGlobal.SocketUtile.ByteToString(this.Data_Byte); }
		
		/// <summary>
		/// 데이터(string), 우선순위 3.
		/// 문자열리스트로된 리스트를 문자열로 변환한 데이터.
		/// </summary>
		public string Data_String { get; set; }


		/// <summary>
		/// 데이터(List), 우선순위 2.
		/// </summary>
		public List<string> Data_List { get; set; }

		/// <summary>
		/// 데이터를 구분하기 위한 고유번호
		/// </summary>
		public int Index { get; set; }
		/// <summary>
		/// 받기나 보내기 작업이 완료되었는지 여부
		/// </summary>
		public bool Complete { get; set; }

		private void ResetClass()
		{
			Data_List = new List<string>();
			this.Complete = false;

			this.Command = CCommand.Command.None;
			this.Data_String = "";
		}

		public CSendData()
		{
			ResetClass();
		}

		public CSendData(CSendData_Original dataOri)
		{
			ResetClass();

			this.DataOriginalToThis(dataOri);
		}

		public CSendData(CCommand.Command typeCommand, string sData = "")
		{
			ResetClass();
			this.Command = typeCommand;
			this.Data_String = sData;
			//입력된 데이터를 변환 한다.
			this.CreateDataSend();
		}

		public CSendData(CCommand.Command typeCommand, params string[] sDatas)
		{
			ResetClass();

			this.Command = typeCommand;

			foreach (string sTemp in sDatas)
			{
				this.Data_List.Add(sTemp);
			}

			//입력된 데이터를 변환 한다.
			this.CreateDataSend();

		}

		/// <summary>
		/// 지정한 리스트의 내용을 구분자를 이용하여 한줄로 만든다.
		/// </summary>
		/// <param name="listString"></param>
		/// <param name="sDivision"></param>
		/// <returns></returns>
		private string ListToString(List<string> listString, string sDivision)
		{
			if( 0 >= listString.Count)
			{	//리스트에 내용이 없으면 빈값을 준다.
				return null;
			}

			//리스트에 내용이 있으면 구분자를 이용하여 한줄로 만든다.
			StringBuilder sbReturn = new StringBuilder();
			//리스트의 내용을 한줄로 만든다.
			foreach (string sFor in listString)
			{
				sbReturn.Append(sFor);
				sbReturn.Append(sDivision);
			}

			return sbReturn.ToString();
		}

		

		/// <summary>
		/// 명령어를 바이트 형태로 바꾼다.
		/// </summary>
		/// <returns></returns>
		private byte[] ByteToCommand()
		{
			//여기의 크기는 'CSocketGlobal.CommandSize'로 결정함
			return CSocketGlobal.SocketUtile.StringToByte(
					string.Format("{0:D4}", this.Command.GetHashCode()));
		}

		/// <summary>
		/// 데이터오리지널을 이 클래스로 만들어 줍니다.
		/// </summary>
		/// <param name="dataOri"></param>
		public void DataOriginalToThis(CSendData_Original dataOri)
		{
			this.DataOriginalToThis(dataOri.Data);
		}

		/// <summary>
		/// 데이터오리지널(바이트형태)을 이클래스로 만들어 줍니다.
		/// </summary>
		/// <param name="byteOri"></param>
		private void DataOriginalToThis(byte[] byteOri)
		{
			byte[] byteTemp;

			//명령어를 잘라 붙여 넣는다.
			byteTemp = new byte[CSocketGlobal.CommandSize];
			//명령어 복사
			Buffer.BlockCopy(byteOri
								, 0
								, byteTemp
								, 0
								, CSocketGlobal.CommandSize);
			//명령어로 변환
			this.Command = (CCommand.Command)CSocketGlobal.SocketUtile.ByteToInt(byteTemp);

			//데이터 복사
			this.Data_Byte = new byte[byteOri.Length - CSocketGlobal.CommandSize];
			Buffer.BlockCopy(byteOri
								, CSocketGlobal.CommandSize
								, this.Data_Byte
								, 0
								, byteOri.Length - CSocketGlobal.CommandSize);
		}

		/// <summary>
		/// 이 클래스를 오리지널 클래스로 바꿔줍니다.
		/// </summary>
		/// <returns></returns>
		public CSendData_Original CreateDataOriginal()
		{
			if ((null == Data_Byte)
				|| (0 >= Data_Byte.Length))
			{	//문자열 데이터다.
				return CreateDataOriginal_String();
			}
			else
			{	//바이트 데이터다.
				return CreateDataOriginal_Byte();
			}
		}

		/// <summary>
		/// 문자열을 오리지널 클래스로 바꿉니다.
		/// </summary>
		/// <returns></returns>
		private CSendData_Original CreateDataOriginal_String()
		{
			//입력된 데이터를 변환 한다.
			this.CreateDataSend();

			//바이트 처리를 한다.
			return CreateDataOriginal_Byte();
		}

		/// <summary>
		/// 바이트를 오리지널 클래스로 바꿉니다.
		/// </summary>
		/// <returns></returns>
		private CSendData_Original CreateDataOriginal_Byte()
		{
			//리턴할 보내기용 원본 데이터
			CSendData_Original dataReturn = new CSendData_Original();
			//데이터 공간 확보
			dataReturn.Data = new byte[CSocketGlobal.CommandSize + this.Data_Byte.Length];

			//명령어 복사
			Buffer.BlockCopy(ByteToCommand()
								, 0
								, dataReturn.Data
								, 0
								, CSocketGlobal.CommandSize);
			//데이터 복사
			Buffer.BlockCopy(this.Data_Byte
								, 0
								, dataReturn.Data
								, CSocketGlobal.CommandSize
								, this.Data_Byte.Length);

			return dataReturn;
		}

		/// <summary>
		/// 입력된 데이터를 한줄짜리 데이터로 변환 합니다.
		/// </summary>
		private void CreateDataSend()
		{
			//문자열리스트를 한줄짜리 문자열로 변환한다.
			string sResult
				= this.ListToString(this.Data_List
									, CSocketGlobal.Division1.ToString());

			if (null != sResult)
			{	//리스트에 내용이 있을 때만 리스트결과를 쓴다.
				this.Data_String = sResult;
			}

			//문자열 데이터를 바이트로 변환 해준다.
			this.Data_Byte = CSocketGlobal.SocketUtile.StringToByte(this.Data_String);
		}


	}
}
