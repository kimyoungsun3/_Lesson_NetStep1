﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;

using DGU_Socket.SendData;
using System.Threading;
using System.Net;

namespace DGU_Socket
{
	#region 외부에 연결할 델리게이트
	/// <summary>
	/// 접속됨
	/// </summary>
	public delegate void dgSocketUser_Connect();
	/// <summary>
	/// 접속끊김을 알림
	/// </summary>
	public delegate void dgSocketUser_Disconnect();

	/// <summary>
	/// 메시지 받기 완료
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	public delegate void dgSocketUser_ReceiveComplete(CSendData_Original sdOri);
	/// <summary>
	/// 메시지 보내기 완료
	/// </summary>
	public delegate void dgSocketUser_SendComplete();
	#endregion

	public class CSocketUser
	{
		#region 연결할 이벤트 ♥♥♥♥♥♥♥♥♥♥♥♥
		/// <summary>
		/// 접속됨
		/// </summary>
		public event dgSocketUser_Connect OnConnect;
		private void OnConnect_Call()
		{
			if (null != this.OnConnect)
			{
				this.OnConnect();
			}
		}
		/// <summary>
		/// 접속이 끊어짐.
		/// 이 이벤트에는 유저 끊기 관련 작업을 하면 안됩니다.
		/// </summary>
		public event dgSocketUser_Disconnect OnDisconnect;
		private void OnDisconnect_Call()
		{
			if (null != this.OnDisconnect)
			{
				this.OnDisconnect();
			}

			//어떤식으로든 접속이 끊어지면 소켓을 초기화한다.
			this.m_socketMe = null;
		}

		/// <summary>
		/// 메시지 받기 완료
		/// </summary>
		public event dgSocketUser_ReceiveComplete OnReceiveComplete;
		private void OnReceiveComplete_Call(CSendData_Original sdOri)
		{
			if (null != this.OnReceiveComplete)
			{
				this.OnReceiveComplete(sdOri);
			}
		}
		/// <summary>
		/// 메시지 보내기가 완료 되었다.
		/// </summary>
		private event dgSocketUser_SendComplete OnSendComplete;
		private void OnSendComplete_Call()
		{
			if (null != this.OnSendComplete)
			{
				this.OnSendComplete();
			}
		}
		#endregion

		/// <summary>
		/// 이 유저의 소켓정보
		/// </summary>
		private Socket m_socketMe { get; set; }

		/// <summary>
		/// 큰데이터 받기용
		/// </summary>
		private CLargeData_Manager_SAEA m_LD_GM
			= new CLargeData_Manager_SAEA(100);
		
		/// <summary>
		/// 소켓을 받아 초기화 합니다.
		/// 이벤트 연결이 끝나면 'BeginReceive()'를 호출하여 데이터를 받을 준비를 해야 합니다.
		/// </summary>
		/// <param name="socketUser"></param>
		public CSocketUser(Socket socketUser)
		{
			this.m_socketMe = socketUser;
		}

		public void BeginReceive()
		{
			if (true == this.m_socketMe.Connected)
			{
				CSendData_Original dsReceiveMsg = new CSendData_Original();
				//연결완료용 데이터는 
				dsReceiveMsg.Data = DGU_CSocket.Util_Buffer.Buffer_GetBasicButter;

				//서버에 보낼 객체를 만든다.
				SocketAsyncEventArgs saeaReceiveArgs = new SocketAsyncEventArgs();
				//보낼 데이터를 설정하고
				saeaReceiveArgs.UserToken = dsReceiveMsg.Data;
				//데이터 길이 세팅
				saeaReceiveArgs.SetBuffer(dsReceiveMsg.getBitConverter()
											, 0
											, dsReceiveMsg.ButterCount);
				//받음 완료 이벤트 연결
				saeaReceiveArgs.Completed += SaeaReceiveArgs_Completed;
				//받음 보냄
				m_socketMe.ReceiveAsync(saeaReceiveArgs);

				//접속됨
				this.OnConnect_Call();
			}
			else
			{//접속이 끊김
				this.OnDisconnect_Call();
			}
		}

		private void SaeaReceiveArgs_Completed(object sender, SocketAsyncEventArgs e)
		{
			//서버에서 넘어온 정보
			Socket socketClient = (Socket)sender;
			//서버에서 넘어온 데이터
			CSendData_Original mdRecieveMsg = new CSendData_Original();
			//메시지 받기가 완료되었는지 여부
			bool bMessageComplete = false;

			if (false == socketClient.Connected)
			{   //유저의 접속이 끊겼다.
				//접속 끊김을 알린다.
				this.OnDisconnect_Call();
				return;
			}


			//리시브된 데이터를 잠깐 기다린다.
			Thread.Sleep(50);

			//리시브된 데이터양을 체크하기전에 데이터를 버퍼로 옮겨야 한다.
			//그래야 중간에 리시브된 데이터에 의한 예외를 피할 수 있다.
			//리시브된 데이터의 양
			int nAvailable = socketClient.Available;
			byte[] byteReciveTemp = new byte[nAvailable];
			if (0 < nAvailable)
			{
				//미리 리시브버퍼을 읽어들여서 이후에 들어오는 리시브데이터에 의한
				//예상하지 못한 동작을 막는다.
				socketClient.Receive(byteReciveTemp
											, nAvailable
											, SocketFlags.None);
#if Debug
				Console.WriteLine("nAvailable : {0}", 0);
#endif
			}
			else if(0 >= this.m_LD_GM.TotalBufferSize)
			{//헤더 버퍼를 읽이 않았다.
			 //헤더 버퍼를 읽지 않은 상황에서 리시브데이터가 없다면 아무런 데이터가 없다는 의미다.
			 //만약을 위한 예외처리다.
				this.m_LD_GM.SkipStep = true;

				//헤더버퍼를 읽은 상태에서도 리시브가 0일 수 있는데 이때는 버퍼에 데이터가
				//들어 있을 확률이 있으므로 그냥 정상처리 하면 된다.
			}



			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Wait))
			{   //데이터를 받는 중이다.

				//전체 버퍼의 크기를 읽어온다.
				mdRecieveMsg.Length = BitConverter.ToInt32(e.Buffer, 0);
#if Debug
				Console.WriteLine("buffer : {0}", mdRecieveMsg.Length);
#endif

				//버퍼에 저장하기를 시작한다.
				this.m_LD_GM.StartBuffer(mdRecieveMsg.Length);
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Receiving))
			{   //데이터를 받는 중이다.

				if (false == this.m_LD_GM.BufferCheck)
				{   //버퍼를 체크하지 않았다.
					//버퍼를 체크하지 않았다면 해더용 버퍼까지 데이터로 취급하여
					//데이터를 받아야 한다.
					this.m_LD_GM.SetBuffer_HeaderTemp(e.Buffer);
				}

				//임시버퍼의 크기를 설정하고
				this.m_LD_GM.SetBuffer_BadyTemp(nAvailable);
				if (0 < nAvailable)
				{//본문에 리시브된 데이터가 있을때만 동작
				 //임시 버퍼에 데이터를 데이터를 넣는다.
					this.m_LD_GM.SetBuffer_BadyTemp(byteReciveTemp);
                    /*socketClient.Receive(this.m_LD_GM.Buffer_BadyTemp
										, socketClient.Available
										, SocketFlags.None);*/
                }
				//임시 버퍼의 데이터를 전체 버퍼로 옮깁니다.
				this.m_LD_GM.WriteBufferTemp_All();
				/*
				Console.WriteLine("ReceiveBufferSize : {0}", e.Count);
				Console.WriteLine("        Available : {0}", nAvailable);

				Console.WriteLine(" BufferCompleat : TotalBufferSize {0} - WriteCount {1} - State {2}"
					, this.m_LD_GM.TotalBufferSize
					, this.m_LD_GM.WriteCount
					, this.m_LD_GM.State.ToString());*/
			}

			if (true == this.m_LD_GM.CheckState(CLargeData_Manager_SAEA.TypeSAEA.Compleat))
			{   //데이터가 완성 되었다.

				//전체 버퍼의 크기를 지정하고.
				mdRecieveMsg.Length = this.m_LD_GM.TotalBufferSize;
				//완성 데이터에 버퍼를 옮기고
				mdRecieveMsg.Data = this.m_LD_GM.Buffer;

				//넘어온 메시지를 분석의뢰!
				//this.OnMessageComplete(new CSendData(mdRecieveMsg));
				bMessageComplete = true;

				//메니저 초기화
				this.m_LD_GM.Reset();
			}

			if (true == this.m_LD_GM.SkipStep)
			{   //스킵하고 왔다면
				//스킵을 복구한다.
				this.m_LD_GM.SkipStep = false;
			}

			//다음 데이터를 기다린다.
			socketClient.ReceiveAsync(e);

			if (true == bMessageComplete)
			{//메시지가 완료 되었다.
			 //넘어온 메시지를 분석의뢰!
				this.OnReceiveComplete_Call(mdRecieveMsg);
			}
		}//end SaeaReceiveArgs_Completed

		public void SendMsg(CSendData dsSendMsg)
		{
			CSendData_Original doSendMsg = dsSendMsg.CreateDataOriginal();

			//서버에 보낼 객체를 만든다.
			SocketAsyncEventArgs saeaServer = new SocketAsyncEventArgs();
			//데이터 길이 세팅
			saeaServer.SetBuffer(doSendMsg.getBitConverter(), 0, doSendMsg.ButterCount);
			//보내기 완료 이벤트 연결
			saeaServer.Completed += new EventHandler<SocketAsyncEventArgs>(Send_Completed);
			//보낼 데이터 설정
			saeaServer.UserToken = doSendMsg.Data;

#if Debug
			Console.WriteLine("Send - Length : {0}, comm : {1}"
								, doSendMsg.Length
								, dsSendMsg.Command);
#endif

			//보내기가 완료되었는지 여부
			bool bCompletedAsync = false;

			try
			{
				//보내기
				bCompletedAsync = m_socketMe.SendAsync(saeaServer);
			}
			catch
			{
				//여기서 에러가나면 보내기는 실패한것이다.
				//다음 작업을 할 수 있도록 처리한다.
			}

			//https://msdn.microsoft.com/ko-kr/library/system.net.sockets.socket.sendasync(v=vs.110).aspx
			if (false == bCompletedAsync)
			{//동기적으로 작업이 완료 되었다.
				//메시지 보내기 완료
				//this.OnSendComplete_Call();
			}
		}

		/// <summary>
		/// 메시지 보내기 완료.
		/// 'OnSendComplete_Call'은 샌드메시지에서 처리하므로 여기서는 하지 않는다.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Send_Completed(object sender, SocketAsyncEventArgs e)
		{
			Socket socketSend = (Socket)sender;
			CSendData_Original dsMsg = new CSendData_Original();
			dsMsg.Data = (byte[])e.UserToken;
			socketSend.Send(dsMsg.Data);
		}

		/// <summary>
		/// 이 유저가 가지고 있는 소켓을 끊습니다.
		/// 이 메소드를 실행하면 'OnDisconnect'이벤트가 발생합니다.
		/// </summary>
		public void Disconnect()
		{
			this.m_socketMe.Disconnect(false);
		}

	}
}

