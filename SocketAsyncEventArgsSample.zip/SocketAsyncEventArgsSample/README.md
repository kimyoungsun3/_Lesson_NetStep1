SocketAsyncEventArgsSample
==========================

A sample to use SocketAsyncEventArgs to build high performance tcp server and client.
