using System;
using System.Net;
using System.Threading;

namespace SocketAsyncServer
{
    static class Program
    {
        private const Int32 DEFAULT_PORT = 7878, DEFAULT_MAX_NUM_CONNECTIONS = 10000, DEFAULT_BUFFER_SIZE = 10000;

        static void Main(String[] args)
        {
            try
            {
                SocketListener listener = new SocketListener(DEFAULT_MAX_NUM_CONNECTIONS, DEFAULT_BUFFER_SIZE);
                listener.Start(new IPEndPoint(IPAddress.Parse("127.0.0.1"), DEFAULT_PORT));

                Console.WriteLine("Server listening on port {0}. Press any key to terminate the server process...", DEFAULT_PORT);
                //Console.Read();
                while (true)
                {
                    Thread.Sleep(1000);
                }
                listener.Stop();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
