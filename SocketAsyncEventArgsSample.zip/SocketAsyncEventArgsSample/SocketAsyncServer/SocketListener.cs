﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace SocketAsyncServer
{
    public sealed class SocketListener
    {
        private const int MessageHeaderSize = 4;
        private int _receivedMessageCount = 0;  //for testing
        private Stopwatch _watch;  //for testing

        private BlockingCollection<MessageData> sendingQueue;
        private Thread sendMessageWorker;

        private static Mutex _mutex = new Mutex();
        private Socket _listenSocket;
        private int _bufferSize;
        private int _connectedSocketCount;
        private int _maxConnectionCount;
        private SocketAsyncEventArgsPool _socketAsyncReceiveEventArgsPool;
        private SocketAsyncEventArgsPool _socketAsyncSendEventArgsPool;
        private Semaphore _acceptedClientsSemaphore;
        private AutoResetEvent waitSendEvent;

        public SocketListener(int maxConnectionCount, int bufferSize)
        {
            _maxConnectionCount = maxConnectionCount;
            _bufferSize = bufferSize;
            _socketAsyncReceiveEventArgsPool = new SocketAsyncEventArgsPool(maxConnectionCount);//받는용 풀링
            _socketAsyncSendEventArgsPool = new SocketAsyncEventArgsPool(maxConnectionCount);//보내는용 풀링
            _acceptedClientsSemaphore = new Semaphore(maxConnectionCount, maxConnectionCount);//세마포어?

            sendingQueue = new BlockingCollection<MessageData>();
            sendMessageWorker = new Thread(SendQueueMessage);

            //받는용 SocketAsyncEventArgs 버퍼와 완료이벤트 설정
            for (int i = 0; i < maxConnectionCount; i++)
            {
                SocketAsyncEventArgs socketAsyncEventArgs = new SocketAsyncEventArgs();
                socketAsyncEventArgs.Completed += OnIOCompleted;
                socketAsyncEventArgs.SetBuffer(new Byte[bufferSize], 0, bufferSize);
                _socketAsyncReceiveEventArgsPool.Push(socketAsyncEventArgs);
            }
            //보내는용 SocketAsyncEventArgs 버퍼와 완료이벤트 설정
            for (int i = 0; i < maxConnectionCount; i++)
            {
                SocketAsyncEventArgs socketAsyncEventArgs = new SocketAsyncEventArgs();
                socketAsyncEventArgs.Completed += OnIOCompleted;
                socketAsyncEventArgs.SetBuffer(new Byte[bufferSize], 0, bufferSize);
                _socketAsyncSendEventArgsPool.Push(socketAsyncEventArgs);
            }

            waitSendEvent = new AutoResetEvent(false);
        }

        public void Start(IPEndPoint localEndPoint)
        {
            _listenSocket = new Socket(localEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            _listenSocket.ReceiveBufferSize = _bufferSize;
            _listenSocket.SendBufferSize = _bufferSize;
            _listenSocket.Bind(localEndPoint);
            _listenSocket.Listen(_maxConnectionCount);
            sendMessageWorker.Start();
            StartAccept(null);
            _mutex.WaitOne();
        }
        public void Stop()
        {
            try
            {
                _listenSocket.Close();
            }
            catch { }
            _mutex.ReleaseMutex();
        }

        private void OnIOCompleted(object sender, SocketAsyncEventArgs e)
        {
            switch (e.LastOperation)
            {
                case SocketAsyncOperation.Receive:
                    ProcessReceive(e);
                    break;
                case SocketAsyncOperation.Send:
                    ProcessSend(e);
                    break;
                default:
                    throw new ArgumentException("The last operation completed on the socket was not a receive or send");
            }
        }
        private void StartAccept(SocketAsyncEventArgs acceptEventArg)
        {
            if (acceptEventArg == null)
            {
                acceptEventArg = new SocketAsyncEventArgs();//null일때 생성처리 (처음 서버시작하면 null임)
                acceptEventArg.Completed += (sender, e) => ProcessAccept(e);
            }
            else
            {
                acceptEventArg.AcceptSocket = null;
            }

            _acceptedClientsSemaphore.WaitOne();
            if (!_listenSocket.AcceptAsync(acceptEventArg))//접속처리
            {
                ProcessAccept(acceptEventArg);
            }
        }
        private void ProcessAccept(SocketAsyncEventArgs e)
        {
            try
            {
                SocketAsyncEventArgs readEventArgs = _socketAsyncReceiveEventArgsPool.Pop();
                if (readEventArgs != null)
                {
                    readEventArgs.UserToken = new AsyncUserToken(e.AcceptSocket);
                    Interlocked.Increment(ref _connectedSocketCount);
                    Console.WriteLine("Client connection accepted. There are {0} clients connected to the server", _connectedSocketCount);
                    if (!e.AcceptSocket.ReceiveAsync(readEventArgs))
                    {
                        ProcessReceive(readEventArgs);
                    }
                }
                else
                {
                    Console.WriteLine("There are no more available sockets to allocate.");
                }
            }
            catch (SocketException ex)
            {
                AsyncUserToken token = e.UserToken as AsyncUserToken;
                Console.WriteLine("Error when processing data received from {0}:\r\n{1}", token.Socket.RemoteEndPoint, ex.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            // 다음 연결 요청을 수락하십시오.
            StartAccept(e);
        }
        private void ProcessReceive(SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                AsyncUserToken token = e.UserToken as AsyncUserToken;

                //수신 데이터 처리
                ProcessReceivedData(token.DataStartOffset, token.NextReceiveOffset - token.DataStartOffset + e.BytesTransferred, 0, token, e);

                //수신 할 다음 데이터의 시작 위치를 업데이트하십시오.
                token.NextReceiveOffset += e.BytesTransferred;

                //버퍼의 끝에 도달하면 NextReceiveOffset을 버퍼의 시작 부분으로 재설정하고 마이그레이션해야 할 처리되지 않은 데이터를 마이그레이션하십시오.
                if (token.NextReceiveOffset == e.Buffer.Length)
                {
                    //NextReceiveOffset을 버퍼의 시작 부분으로 재설정
                    token.NextReceiveOffset = 0;

                    //아직 처리되지 않은 데이터가있는 경우 데이터를 데이터 버퍼의 시작 부분으로 마이그레이션하십시오.
                    if (token.DataStartOffset < e.Buffer.Length)
                    {
                        var notYesProcessDataSize = e.Buffer.Length - token.DataStartOffset;
                        Buffer.BlockCopy(e.Buffer, token.DataStartOffset, e.Buffer, 0, notYesProcessDataSize);

                        //데이터가 버퍼의 시작 부분으로 마이그레이션 된 후 NextReceiveOffset을 다시 업데이트해야합니다.
                        token.NextReceiveOffset = notYesProcessDataSize;
                    }

                    token.DataStartOffset = 0;
                }

                //다음에 수신 된 데이터의 시작 위치와 수신 가능한 데이터의 최대 길이를 업데이트하십시오.
                e.SetBuffer(token.NextReceiveOffset, e.Buffer.Length - token.NextReceiveOffset);

                //후속 데이터 수신
                if (!token.Socket.ReceiveAsync(e))
                {
                    ProcessReceive(e);
                }
            }
            else
            {
                CloseClientSocket(e);
            }
        }
        private void ProcessReceivedData(int dataStartOffset, int totalReceivedDataSize, int alreadyProcessedDataSize, AsyncUserToken token, SocketAsyncEventArgs e)
        {
            if (alreadyProcessedDataSize >= totalReceivedDataSize)
            {
                return;
            }

            if (token.MessageSize == null)
            {
                //이전에 수신 된 데이터와 현재 수신 된 데이터에 메시지 헤더 크기보다 큰 경우 메시지 헤더를 구문 분석 할 수 있습니다.
                if (totalReceivedDataSize > MessageHeaderSize)
                {
                    //메시지 길이 분석
                    var headerData = new byte[MessageHeaderSize];
                    Buffer.BlockCopy(e.Buffer, dataStartOffset, headerData, 0, MessageHeaderSize);
                    var messageSize = BitConverter.ToInt32(headerData, 0);

                    token.MessageSize = messageSize;
                    token.DataStartOffset = dataStartOffset + MessageHeaderSize;

                    //재귀 처리
                    ProcessReceivedData(token.DataStartOffset, totalReceivedDataSize, alreadyProcessedDataSize + MessageHeaderSize, token, e);
                }
                //이전에 수신 된 데이터와 현재 수신 된 데이터가 여전히 메시지 헤더의 크기보다 크지 않으면 후속 바이트를 수신해야합니다.
                else
                {
                    //여기서 할 일이 없습니다
                }
            }
            else
            {
                var messageSize = token.MessageSize.Value;
                //처리 된 바이트 수에서 현재 누적 된 바이트 수를 뺀 값이 메시지 길이보다 큰지 확인하고, 더 큰 경우 메시지를 구문 분석 할 수 있음을 나타냅니다.
                if (totalReceivedDataSize - alreadyProcessedDataSize >= messageSize)
                {
                    var messageData = new byte[messageSize];
                    Buffer.BlockCopy(e.Buffer, dataStartOffset, messageData, 0, messageSize);
                    ProcessMessage(messageData, token, e);

                    //메시지가 처리 된 후 다음 메시지를 받으려면 토큰을 정리해야합니다.
                    token.DataStartOffset = dataStartOffset + messageSize;
                    token.MessageSize = null;

                    //재귀 처리
                    ProcessReceivedData(token.DataStartOffset, totalReceivedDataSize, alreadyProcessedDataSize + messageSize, token, e);
                }
                //남은 바이트 수는 메시지로 변환하기에 충분하지 않으므로 후속 바이트를 계속 수신해야합니다.
                else
                {
                    //여기서 할 일이 없습니다
                }
            }
        }
        private void ProcessMessage(byte[] messageData, AsyncUserToken token, SocketAsyncEventArgs e)
        {
            var current = Interlocked.Increment(ref _receivedMessageCount);
            if (current == 1)
            {
                _watch = Stopwatch.StartNew();
            }
            if (current % 10000 == 0)
            {
                //Console.WriteLine("text:{0}, count:{1}, timeSpent:{2}", Encoding.UTF8.GetString(messageData), current, _watch.ElapsedMilliseconds);
                Console.WriteLine("received message, length:{0}, count:{1}, timeSpent:{2}", messageData.Length, current, _watch.ElapsedMilliseconds);
            }
            sendingQueue.Add(new MessageData { Message = messageData, Token = token });
        }
        private void ProcessSend(SocketAsyncEventArgs e)
        {
            _socketAsyncSendEventArgsPool.Push(e);
            waitSendEvent.Set();
        }
        private void SendQueueMessage()
        {
            while (true)
            {
                var messageData = sendingQueue.Take();
                if (messageData != null)
                {
                    SendMessage(messageData, BuildMessage(messageData.Message));
                }
            }
        }
        private void SendMessage(MessageData messageData, byte[] message)
        {
            var sendEventArgs = _socketAsyncSendEventArgsPool.Pop();
            if (sendEventArgs != null)
            {
                sendEventArgs.SetBuffer(message, 0, message.Length);
                sendEventArgs.UserToken = messageData.Token;
                messageData.Token.Socket.SendAsync(sendEventArgs);
            }
            else
            {
                waitSendEvent.WaitOne();
                SendMessage(messageData, message);
            }
        }
        static byte[] BuildMessage(byte[] data)
        {
            var header = BitConverter.GetBytes(data.Length);
            var message = new byte[header.Length + data.Length];
            header.CopyTo(message, 0);
            data.CopyTo(message, header.Length);
            return message;
        }
        private void CloseClientSocket(SocketAsyncEventArgs e)
        {
            var token = e.UserToken as AsyncUserToken;
            token.Dispose();
            _acceptedClientsSemaphore.Release();
            Interlocked.Decrement(ref _connectedSocketCount);
            Console.WriteLine("A client has been disconnected from the server. There are {0} clients connected to the server", _connectedSocketCount);
            _socketAsyncReceiveEventArgsPool.Push(e);
        }
    }
}