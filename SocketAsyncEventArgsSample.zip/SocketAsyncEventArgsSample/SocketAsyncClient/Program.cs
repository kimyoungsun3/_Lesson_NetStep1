using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SocketAsyncClient
{
    static class Program
    {
        public static int _receivedMessageCount = 0;  //for testing
        public static Stopwatch _watch;  //for testing

        public static string RandomString(int length)
        {
            Random random = new Random((int)DateTime.Now.Ticks);
            StringBuilder sb = new StringBuilder();

            string validChars = "abcdefghijklmnopqrstuvwxyz0123456789";
            char c;
            for (int i = 0; i < length; i++)
            {
                c = validChars[random.Next(0, validChars.Length)];
                sb.Append(c);
            }

            return sb.ToString();
        }

        static void Main(string[] args)
        {
            try
            {
                int iterations = 25000;
                int clientCount = 1024;
                int messageSize = 1024 * 1;
                var data = new byte[messageSize];
                //data = Encoding.UTF8.GetBytes(RandomString(messageSize));
                //var message = BuildMessage(data);
                var message = BuildMessage(Encoding.UTF8.GetBytes(RandomString(messageSize)));
                var action = new Action<SocketClient>((client) =>
                {
                    for (var i = 0; i < iterations; i++)
                    {
                        client.Send(message);
                    }
                });

                List<SocketClient> clientList = new List<SocketClient>();
                var serverIP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 7878);
                for (var index = 0; index < clientCount; index++)
                {
                    var client = new SocketClient(serverIP);
                    client.Connect();
                    clientList.Add(client);
                }
                foreach(var client in clientList)
                {
                    Task.Factory.StartNew(() => action(client));
                }

                Console.WriteLine("Press any key to terminate the client process...");
                Console.Read();
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
                Console.Read();
            }
        }
        static byte[] BuildMessage(byte[] data)
        {
            var header = BitConverter.GetBytes(data.Length);
            var message = new byte[header.Length + data.Length];
            header.CopyTo(message, 0);
            data.CopyTo(message, header.Length);
            return message;
        }
    }
}
