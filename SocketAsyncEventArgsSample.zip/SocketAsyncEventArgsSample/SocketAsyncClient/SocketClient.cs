﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SocketAsyncClient
{
    public sealed class SocketClient : IDisposable
    {
        private int bufferSize = 60000;
        private const int MessageHeaderSize = 4;

        private Socket clientSocket;
        private bool connected = false;
        private IPEndPoint hostEndPoint;
        private AutoResetEvent autoConnectEvent;
        private AutoResetEvent autoSendEvent;
        private SocketAsyncEventArgs sendEventArgs;
        private SocketAsyncEventArgs receiveEventArgs;
        private BlockingCollection<byte[]> sendingQueue;
        private BlockingCollection<byte[]> receivedMessageQueue;
        private Thread sendMessageWorker;
        private Thread processReceivedMessageWorker;

        public SocketClient(IPEndPoint hostEndPoint)
        {
            this.hostEndPoint = hostEndPoint;
            this.autoConnectEvent = new AutoResetEvent(false);
            this.autoSendEvent = new AutoResetEvent(false);
            this.sendingQueue = new BlockingCollection<byte[]>();
            this.receivedMessageQueue = new BlockingCollection<byte[]>();
            this.clientSocket = new Socket(this.hostEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);//서버대상으로 소켓생성
            this.sendMessageWorker = new Thread(SendQueueMessage);//샌드메세지큐가 차있으면 지속적인 전송
            this.processReceivedMessageWorker = new Thread(ProcessReceivedMessage);//리시브메세지큐가 차있으면 지속적인 수신

            this.sendEventArgs = new SocketAsyncEventArgs();//전송용SocketAsyncEventArgs
            this.sendEventArgs.UserToken = this.clientSocket;//소켓할당
            this.sendEventArgs.RemoteEndPoint = this.hostEndPoint;//서버할당
            this.sendEventArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnSend);

            this.receiveEventArgs = new SocketAsyncEventArgs();//수신용SocketAsyncEventArgs
            this.receiveEventArgs.UserToken = new AsyncUserToken(clientSocket);//소켓할당
            this.receiveEventArgs.RemoteEndPoint = this.hostEndPoint;//서버할당
            this.receiveEventArgs.SetBuffer(new Byte[bufferSize], 0, bufferSize);//버퍼 크기할당
            this.receiveEventArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnReceive);
        }

        public void Connect()
        {
            SocketAsyncEventArgs connectArgs = new SocketAsyncEventArgs();//서버접속을 위한 SocketAsyncEventArgs생성
            connectArgs.UserToken = this.clientSocket;//UserToken인자에 소켓 할당
            connectArgs.RemoteEndPoint = this.hostEndPoint;//RemoteEndPoint에 서버 할당
            connectArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnConnect);

            clientSocket.ConnectAsync(connectArgs);//서버에 비동기접속
            autoConnectEvent.WaitOne();//접속대기

            SocketError errorCode = connectArgs.SocketError;
            if (errorCode != SocketError.Success)
            {
                throw new SocketException((Int32)errorCode);
            }
            sendMessageWorker.Start();//샌드메세지큐가 차있으면 지속적인 전송
            processReceivedMessageWorker.Start();//리시브메세지큐가 차있으면 지속적인 수신

            if (!clientSocket.ReceiveAsync(receiveEventArgs))
            {
                ProcessReceive(receiveEventArgs);
            }
        }

        public void Disconnect()
        {
            clientSocket.Disconnect(false);
        }
        public void Send(byte[] message)
        {
            sendingQueue.Add(message);
        }

        private void OnConnect(object sender, SocketAsyncEventArgs e)
        {
            autoConnectEvent.Set();
            connected = (e.SocketError == SocketError.Success);
        }
        private void OnSend(object sender, SocketAsyncEventArgs e)
        {
            autoSendEvent.Set();
        }
        private void SendQueueMessage()//메세지큐가 차있으면 지속적인 전송
        {
            while (true)
            {
                var message = sendingQueue.Take();
                if (message != null)
                {
                    sendEventArgs.SetBuffer(message, 0, message.Length);//버퍼 크기할당
                    clientSocket.SendAsync(sendEventArgs);
                    autoSendEvent.WaitOne();
                }
            }
        }

        private void OnReceive(object sender, SocketAsyncEventArgs e)
        {
            ProcessReceive(e);
        }
        private void ProcessReceive(SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                AsyncUserToken token = e.UserToken as AsyncUserToken;

                //수신 데이터 처리
                ProcessReceivedData(token.DataStartOffset, token.NextReceiveOffset - token.DataStartOffset + e.BytesTransferred, 0, token, e);

                //수신 할 다음 데이터의 시작 위치를 업데이트하십시오.
                token.NextReceiveOffset += e.BytesTransferred;

                //버퍼의 끝에 도달하면 NextReceiveOffset을 버퍼의 시작 부분으로 재설정하고 마이그레이션해야 할 처리되지 않은 데이터를 마이그레이션하십시오.
                if (token.NextReceiveOffset == e.Buffer.Length)
                {
                    //NextReceiveOffset을 버퍼의 시작 부분으로 재설정
                    token.NextReceiveOffset = 0;

                    //아직 처리되지 않은 데이터가있는 경우 데이터를 데이터 버퍼의 시작 부분으로 마이그레이션하십시오.
                    if (token.DataStartOffset < e.Buffer.Length)
                    {
                        var notYesProcessDataSize = e.Buffer.Length - token.DataStartOffset;
                        Buffer.BlockCopy(e.Buffer, token.DataStartOffset, e.Buffer, 0, notYesProcessDataSize);

                        //데이터가 버퍼의 시작 부분으로 마이그레이션 된 후 NextReceiveOffset을 다시 업데이트해야합니다.
                        token.NextReceiveOffset = notYesProcessDataSize;
                    }

                    token.DataStartOffset = 0;
                }

                //다음에 수신 된 데이터의 시작 위치와 수신 가능한 데이터의 최대 길이를 업데이트하십시오.
                e.SetBuffer(token.NextReceiveOffset, e.Buffer.Length - token.NextReceiveOffset);

                //후속 데이터 수신
                if (!token.Socket.ReceiveAsync(e))
                {
                    ProcessReceive(e);
                }
            }
            else
            {
                ProcessError(e);
            }
        }
        private void ProcessReceivedData(int dataStartOffset, int totalReceivedDataSize, int alreadyProcessedDataSize, AsyncUserToken token, SocketAsyncEventArgs e)
        {
            if (alreadyProcessedDataSize >= totalReceivedDataSize)
            {
                return;
            }

            if (token.MessageSize == null)
            {
                //이전에 수신 된 데이터와 현재 수신 된 데이터에 메시지 헤더 크기보다 큰 경우 메시지 헤더를 구문 분석 할 수 있습니다.
                if (totalReceivedDataSize > MessageHeaderSize)
                {
                    //메시지 길이 분석
                    var headerData = new byte[MessageHeaderSize];
                    Buffer.BlockCopy(e.Buffer, dataStartOffset, headerData, 0, MessageHeaderSize);
                    var messageSize = BitConverter.ToInt32(headerData, 0);

                    token.MessageSize = messageSize;
                    token.DataStartOffset = dataStartOffset + MessageHeaderSize;

                    //재귀 처리
                    ProcessReceivedData(token.DataStartOffset, totalReceivedDataSize, alreadyProcessedDataSize + MessageHeaderSize, token, e);
                }
                //이전에 수신 된 데이터와 현재 수신 된 데이터가 여전히 메시지 헤더의 크기보다 크지 않으면 후속 바이트를 수신해야합니다.
                else
                {
                    //여기서 할 일이 없습니다
                }
            }
            else
            {
                var messageSize = token.MessageSize.Value;
                //처리 된 바이트 수에서 현재 누적 된 바이트 수를 뺀 값이 메시지 길이보다 큰지 확인하고, 더 큰 경우 메시지를 구문 분석 할 수 있음을 나타냅니다.
                if (totalReceivedDataSize - alreadyProcessedDataSize >= messageSize)
                {
                    var messageData = new byte[messageSize];
                    Buffer.BlockCopy(e.Buffer, dataStartOffset, messageData, 0, messageSize);
                    ProcessMessage(messageData);

                    //메시지가 처리 된 후 다음 메시지를 받으려면 토큰을 정리해야합니다.
                    token.DataStartOffset = dataStartOffset + messageSize;
                    token.MessageSize = null;

                    //재귀 처리
                    ProcessReceivedData(token.DataStartOffset, totalReceivedDataSize, alreadyProcessedDataSize + messageSize, token, e);
                }
                //남은 바이트 수는 메시지로 변환하기에 충분하지 않으므로 후속 바이트를 계속 수신해야합니다.
                else
                {
                    //여기서 할 일이 없습니다
                }
            }
        }
        private void ProcessMessage(byte[] messageData)
        {
            receivedMessageQueue.Add(messageData);
        }
        private void ProcessReceivedMessage()//리시브메세지큐가 차있으면 지속적인 수신
        {
            while (true)
            {
                var message = receivedMessageQueue.Take();
                if (message != null)
                {
                    var current = Interlocked.Increment(ref Program._receivedMessageCount);
                    if (current == 1)
                    {
                        Program._watch = Stopwatch.StartNew();
                    }
                    if (current % 1000 == 0)
                    {
                        Console.WriteLine("received reply message, length:{0}, count:{1}, timeSpent:{2}", message.Length, current, Program._watch.ElapsedMilliseconds);
                    }
                }
            }
        }

        private void ProcessError(SocketAsyncEventArgs e)
        {
            //Socket s = e.UserToken as Socket;
            //if (s.Connected)
            //{
            //    // close the socket associated with the client
            //    try
            //    {
            //        s.Shutdown(SocketShutdown.Both);
            //    }
            //    catch (Exception)
            //    {
            //        // throws if client process has already closed
            //    }
            //    finally
            //    {
            //        if (s.Connected)
            //        {
            //            s.Close();
            //        }
            //    }
            //}

            // Throw the SocketException
            throw new SocketException((Int32)e.SocketError);
        }

        #region IDisposable Members

        public void Dispose()
        {
            autoConnectEvent.Close();
            if (this.clientSocket.Connected)
            {
                this.clientSocket.Close();
            }
        }

        #endregion
    }
}