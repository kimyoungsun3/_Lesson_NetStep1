﻿using System;
using System.Collections.Generic;

namespace SocketGlobal.LargeData
{
	#region 연결할 델리게이트
	#endregion

	/// <summary>
	/// SocketAsyncEventArgs를 사용할때 큰 데이터(Large Data)를 처리하기 위한 클래스.
	/// </summary>
	public class claLargeData_GetManager_SAEA
	{
		/*
		 * SocketAsyncEventArgs를 이용하여 데이터를 보내게 되면 설정된 버퍼 만큼만 한번에 받는다.
		 * 그리고 남은 데이터는 다음 Socket.ReceiveAsync에서 받게 된다.
		 * 이 클래스에서는 모든 데이터가 올때까지 임시버퍼를 만들어 저장해 두고 
		 * 모든 데이터가 도착하면 데이터를 꺼내 쓰도록 한다.
		 */

		#region 연결할 이벤트 ♥♥♥♥♥♥♥♥♥♥♥♥
		#endregion

		#region 생성 옵션
		#endregion

		/// <summary>
		/// SocketAsyncEventArgs를 이용한 데이터 받기 상태 정보
		/// </summary>
		public enum TypeSAEA
		{
			/// <summary>
			/// 대기중
			/// </summary>
			Wait = 0,
			/// <summary>
			/// 받는중
			/// </summary>
			Receiving,
			/// <summary>
			/// 받기 완료
			/// </summary>
			Compleat,
		}

		/// <summary>
		/// 임시로 저장해둘 버퍼해더입니다.
		/// </summary>
		public byte[] Buffer_HeaderTemp { get; set; }
		/// <summary>
		/// 임시로 저장해둘 버퍼입니다.
		/// </summary>
		public byte[] Buffer_BadyTemp { get; set; }


		/// <summary>
		/// 전체 버퍼
		/// </summary>
		public byte[] Buffer { get; private set; }
		/// <summary>
		/// 전체 버퍼 사이즈
		/// </summary>
		public int TotalBufferSize { get; private set; }
		/// <summary>
		/// 데이터 수신 상황
		/// </summary>
		public TypeSAEA State { get; private set; }
		/// <summary>
		/// 'State' 체크를 건너 뛴다.
		/// </summary>
		public bool SkipStep { get; set; }
		/// <summary>
		/// 버퍼를 체크했는지 여부
		/// </summary>
		public bool BufferCheck { get; set; }

		/// <summary>
		/// 지금까지 기록된 버퍼의 양
		/// </summary>
		public int WriteCount { get; private set; }

		/// <summary>
		/// 
		/// </summary>
		public void Reset()
		{
			this.Buffer_HeaderTemp = null;
			this.Buffer_BadyTemp = null;
			this.Buffer = null;
			this.TotalBufferSize = 0;
			this.State = TypeSAEA.Wait;
			this.WriteCount = 0;
			this.SkipStep = false;
			this.BufferCheck = false;	
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="nReceiveDelay">리시브를 기다려주는 시간(밀리초)</param>
		public claLargeData_GetManager_SAEA(int nReceiveDelay)
		{
			//this.m_nReceiveDelay = nReceiveDelay;
			Reset();
		}

		/// <summary>
		/// 해당 상태를 진행해도 되는지 여부를 확인한다.
		/// </summary>
		/// <param name="typeState"></param>
		/// <returns></returns>
		public bool CheckState(TypeSAEA typeState)
		{
			bool bReturn = false;

			if (this.State == typeState)
			{	//같은 상태다.
				if (false == this.SkipStep)
				{	//스킵을 하지 않는다.

					bReturn = true;
				}
			}

			return bReturn;
		}

		/// <summary>
		/// 버퍼에 받기를 시작한다.
		/// </summary>
		/// <param name="nTotalBuffer">받아야할 전체 버퍼양</param>
		public void StartBuffer(int nTotalBuffer)
		{
			this.TotalBufferSize = nTotalBuffer;
			this.Buffer = new byte[this.TotalBufferSize];
			//데이터 받기가 시작되었음을 알린다.
			this.State = TypeSAEA.Receiving;
			//첫번째 체크를 했다.
			this.BufferCheck = true;
		}

		/// <summary>
		/// 헤더용 버퍼를 임시 저장한다.
		/// </summary>
		/// <param name="byteHeader"></param>
		public void SetBuffer_HeaderTemp(byte[] byteHeader)
		{
			this.Buffer_HeaderTemp = byteHeader;
		}

		/// <summary>
		/// 임시 버퍼의 크기를 설정하여 생성합니다.
		/// </summary>
		/// <param name="nBufferTempSize"></param>
		public void SetBuffer_BadyTemp(int nBufferTempSize)
		{
			this.Buffer_BadyTemp = new byte[nBufferTempSize];
		}

		/// <summary>
		/// 임시버퍼의 데이터를 전체 버퍼로 옮깁니다.
		/// </summary>
		/// <returns>전체 버퍼가 완성 되었는지 여부 입니다.</returns>
		public TypeSAEA WriteBufferTemp_All()
		{
			if (null != this.Buffer_HeaderTemp)
			{	//임시헤더버퍼에 데이터가 있다.
				//임시헤더버퍼의 내용을 먼저 기록한다.
				WriteBuffer(this.Buffer_HeaderTemp);
			}

			//전체 버퍼로 임시버퍼를 복사한다.
			WriteBuffer(this.Buffer_BadyTemp);

			//임시헤더버퍼를 사용하였으므로 초기화 해준다.
			this.BufferCheck = false;
			this.Buffer_HeaderTemp = null;

			return BufferCompleat();
		}

		/// <summary>
		/// 지정한 데이터를 전체 버퍼로 복사합니다.
		/// </summary>
		/// <param name="byteData"></param>
		private void WriteBuffer(byte[] byteData)
		{
			//전체 버퍼로 임시버퍼를 복사한다.
			System.Buffer.BlockCopy(byteData
									, 0
									, this.Buffer
									, this.WriteCount
									, byteData.Length);

			//기록된 양을 저장해준다.
			this.WriteCount += byteData.Length;

		}

		public TypeSAEA BufferCompleat()
		{
			if (this.TotalBufferSize <= this.WriteCount)
			{
				this.State = TypeSAEA.Compleat;
			}

			return this.State;
		}

	}
}
