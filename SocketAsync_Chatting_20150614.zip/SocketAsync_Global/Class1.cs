﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocketAsync_Global
{
    public class Class1
    {
    }
}
