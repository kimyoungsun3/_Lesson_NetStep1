﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using SocketGlobal.CustomClass;

namespace SocketGlobal
{
	/// <summary>
	/// 데이터 구조체
	/// </summary>
	public class MessageData
	{
		/// <summary>
		/// 헤더 크기
		/// </summary>
		private int m_nCommandHeader;

		/// <summary>
		/// 데이터 전체 길이(명령헤더 + 데이터)
		/// </summary>
		public int m_nData_Ori_Length;
		/// <summary>
		/// 원본 데이터(명령헤더 + 데이터)(원본)
		/// </summary>
		private byte[] m_byteData_Ori;

		/// <summary>
		/// 지정된 명령어
		/// </summary>
		public claCommand.Command TypeCommand { get; private set; }

		/// <summary>
		/// 원본 데이터(데이터 - 명령헤더)
		/// </summary>
		private byte[] m_byteCutData;

		public MessageData()
		{
			//명령어 초기화
			this.TypeCommand = claCommand.Command.None;
			//명령어가 차지하는 크기를 계산한다.
			this.m_nCommandHeader = this.CommandToByte().Length;
		}

		public void SetLength(byte[] Data)
		{
			/*if (Data.Length < 4)
				return;*/
			m_nData_Ori_Length = BitConverter.ToInt32(Data, 0);
		}
		public int DataLength
		{
			get { return m_nData_Ori_Length; }
		}
		public void InitData()
		{
			m_byteData_Ori = new byte[m_nData_Ori_Length];
		}

		/// <summary>
		/// 원본 데이터(명령헤더 + 데이터)
		/// </summary>
		public byte[] Data_Ori
		{
			get { return m_byteData_Ori; }
			set { m_byteData_Ori = value; }
		}

		/// <summary>
		/// 저장된 원본에서 명령어를 분리하여 저장합니다.
		/// 남은 데이터는 원본데이터로 저장됩니다.
		/// </summary>
		public void CutCommand()
		{
			byte[] byteTemp;

			//명령어를 잘라 붙여 넣는다.
			byteTemp = new byte[this.m_nCommandHeader];
			//명령어 복사
			Buffer.BlockCopy(this.m_byteData_Ori
								, 0
								, byteTemp
								, 0
								, this.m_nCommandHeader);
			//명령어로 변환
			this.TypeCommand = (claCommand.Command)claGlobal.g_Number.StringToInt(this.ByteToString(byteTemp));

			//데이터 복사
			this.m_byteCutData = new byte[this.m_nData_Ori_Length - this.m_nCommandHeader];
			Buffer.BlockCopy(this.m_byteData_Ori
								, this.m_nCommandHeader
								, this.m_byteCutData
								, 0
								, this.m_nData_Ori_Length - this.m_nCommandHeader);

			MemoryStream ms = new MemoryStream();

		}


		public byte[] GetData_Byte()
		{
			return this.m_byteCutData;
		}
		public String GetData_String()
		{
			return this.ByteToString(m_byteCutData);
		}

		


		public byte[] GetBuffer()
		{
			return new byte[4];
			//return Encoding.UTF8.GetBytes();
		}

		public void SetData(claCommand.Command typeCommand, String Data)
		{
			//데이터를 바이트로 바꾸고 전달 한다.
			this.SetData(typeCommand, this.StringToByte(Data));
		}

		public void SetData(claCommand.Command typeCommand, byte[] byteData)
		{
			this.TypeCommand = typeCommand;

			//명령어를 바이트로 바꾸고
			byte[] byteCommand = this.CommandToByte();

			//오리지널 데이터공간을 만든다.
			this.m_byteData_Ori = new byte[this.m_nCommandHeader + byteData.Length];
			this.m_nData_Ori_Length = this.m_byteData_Ori.Length;


			//명령어 복사
			Buffer.BlockCopy(byteCommand
								, 0
								, this.m_byteData_Ori
								, 0
								, this.m_nCommandHeader);
			//데이터 복사
			Buffer.BlockCopy(byteData
								, 0
								, this.m_byteData_Ori
								, this.m_nCommandHeader
								, byteData.Length);
		}

		private byte[] CommandToByte()
		{
			//명령어는 무조건 4칸을 차지한다.
			return this.StringToByte( string.Format("{0:D4}", this.TypeCommand.GetHashCode()));
		}

		private byte[] StringToByte(string sData)
		{
			return Encoding.UTF8.GetBytes(sData);
		}

		private string ByteToString(byte[] byteData)
		{
			return Encoding.UTF8.GetString(byteData, 0, byteData.Length);
		}
	}

	public enum ChatType
	{
		Send,
		Receive,
		System
	}

	public class claGlobal
	{
		public static string g_SiteTitle = "Socket - SocketAsyncEventArgs";

		/// <summary>
		/// 명령어 구분용 문자
		/// </summary>
		public static char g_Division = '▦';

		public static claNumber g_Number = new claNumber();
	}
}
