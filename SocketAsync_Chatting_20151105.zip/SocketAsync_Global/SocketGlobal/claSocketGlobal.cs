﻿using System;

namespace SocketGlobal
{
	/// <summary>
	/// 하위 폴더에 있는 클래스들에 사용하기 위해 이미 스택틱(static)으로 선언된 내용을 다시 선언한다.
	/// 이렇게 하면 이 폴더만 다른 프로젝트로 옮기더라로 여기만 수정 하면 된다.
	/// </summary>
	public class claSocketGlobal
	{
		/// <summary>
		/// 명령어 구분용 문자1
		/// </summary>
		public static char Division1 = claGlobal.g_Division1;
		/// <summary>
		/// 명령어 구분용 문자1
		/// </summary>
		public static char Division2 = claGlobal.g_Division2;

		/// <summary>
		/// 최대 버퍼 사이즈
		/// </summary>
		public static int FullBuffer = claGlobal.g_FullBuffer;

		/// <summary>
		/// 명령어의 크기
		/// </summary>
		public static int CommandSize = claGlobal.g_CommandSize;
		/// <summary>
		/// 메시지의 데이터크기가 큰경우 자르기위한 크기.
		/// </summary>
		public static int CutByteSize = claGlobal.g_CutByteSize;

		/// <summary>
		/// 데이터에 별도의 헤더1을 붙이는 경우 해더의 크기
		/// </summary>
		public static int DataHeader1Size = claGlobal.g_DataHeader1Size;
		/// <summary>
		/// 데이터에 별도의 헤더2을 붙이는 경우 해더의 크기
		/// </summary>
		public static int DataHeader2Size = claGlobal.g_DataHeader2Size;

		/// <summary>
		/// 소켓에서 사용되는 변환 관련 유틸들
		/// </summary>
		public static claSocketUtile SocketUtile = claGlobal.g_SocketUtile;

	}
}
