﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JWT4_Sell_ask
{
	public class AskBid
	{

	}
}
