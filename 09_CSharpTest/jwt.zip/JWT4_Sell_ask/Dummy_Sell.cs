﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JWT4_Sell_ask
{
	class Dummy_Sell
	{
		/*			
			//판매... 5만원이 50 -> 0.5%
			string coinCode = "KRW-BTC";
			decimal COIN_PRICE_ASK = 10400000m + 1.0m * 0;
			int COIN_HOGA_ASK = +20;
			int ORDER_ASK_LOOP = 50;
			decimal COIN_MONEY_ASK = 1002m;

			//판매
			string coinCode = "KRW-EOS";
			decimal COIN_PRICE_ASK = 9680m + 0.3m * 0;
			int COIN_HOGA_ASK = +2;
			int ORDER_ASK_LOOP = 10;
			decimal COIN_MONEY_ASK = 20000m;

			//판매
			string coinCode = "KRW-MOC";
			decimal COIN_PRICE_ASK = 64.8m + 0.3m * 0;
			int COIN_HOGA_ASK = +1;
			int ORDER_ASK_LOOP = 40;
			decimal COIN_MONEY_ASK = 50000m;

			//판매...
			string coinCode = "KRW-CPT";
			decimal COIN_PRICE_ASK = 9.24m + 1.0m * 0;
			int COIN_HOGA_ASK = +1;
			int ORDER_ASK_LOOP = 5;
			decimal COIN_MONEY_ASK = 2000m;

			//판매...
			string coinCode = "KRW-ENJ";
			decimal COIN_PRICE_ASK = 435m + 1.0m * 0;
			int COIN_HOGA_ASK = +2;
			int ORDER_ASK_LOOP = 70;
			decimal COIN_MONEY_ASK = 50000m;
		
			//판매
			string coinCode = "KRW-BAT";
			decimal COIN_PRICE_ASK = 435m + 1.0m * 0;
			int COIN_HOGA_ASK = +2;
			int ORDER_ASK_LOOP = 70;
			decimal COIN_MONEY_ASK = 50000m;
		/**/
	}
}
