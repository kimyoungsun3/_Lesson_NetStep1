﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JWT4_Buy_bid
{
	class Dummy_Sell
	{
		/*
			//매수
			string coinCode = "KRW-BTC";
			decimal COIN_PRICE_BID = 10270000m - 20.0m * 0;
			int COIN_HOGA_BID = -15;
			int ORDER_BID_LOOP = 50;
			decimal COIN_MONEY_BID = 10000m;
		
			//매수
			string coinCode = "KRW-EOS";
			decimal COIN_PRICE_BID = 8500m - 20.0m * 0;
			int COIN_HOGA_BID = -3;
			int ORDER_BID_LOOP = 40;
			decimal COIN_MONEY_BID = 10000m;		

			//매수
			string coinCode = "KRW-MOC";
			decimal COIN_PRICE_BID = 56.0m - .3m * 0;
			int COIN_HOGA_BID = -1;
			int ORDER_BID_LOOP = 30;
			decimal COIN_MONEY_BID = 7000m;

			//매수
			string coinCode = "KRW-CPT";
			decimal COIN_PRICE_BID = 9.08m - .2m * 0;
			int COIN_HOGA_BID = -1;
			int ORDER_BID_LOOP = 60;
			decimal COIN_MONEY_BID = 2000m;

			//매수
			string coinCode = "KRW-ENJ";
			decimal COIN_PRICE_BID = 178m - 1m * 0;
			int COIN_HOGA_BID = -1;
			int ORDER_BID_LOOP = 20;
			decimal COIN_MONEY_BID = 20000m;

			//매수
			string coinCode = "KRW-BAT";
			decimal COIN_PRICE_BID = 399m - .3m * 0;
			int COIN_HOGA_BID = -1;
			int ORDER_BID_LOOP = 60;
			decimal COIN_MONEY_BID = 7000m;
		/**/
	}
}
