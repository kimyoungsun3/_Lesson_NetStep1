﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JWT4_Buy_bid
{
	public class AskBid
	{

	}
}
