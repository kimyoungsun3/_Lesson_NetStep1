﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JsonTest
{
	public class Debug
	{
		public static void Log(string _str)
		{
			Console.WriteLine(_str);
		}

		public static void Log(float _str)
		{
			Console.WriteLine(_str);
		}

		public static void Log(int _str)
		{
			Console.WriteLine(_str);
		}
	}
}
