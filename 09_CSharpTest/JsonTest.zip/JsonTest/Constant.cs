﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonTest
{
	public class Constant
	{
		public const int LOOP_MAX		= 100_000;
		public const int SLEEP_TIME		= 1000;
	}
}
